﻿using System;
using System.ComponentModel.DataAnnotations;

namespace SampleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var appLoger = new AppLogger();
            appLoger.LogInfo("App started");
            var vehicle = new Vehicle();
            AddCoverage.Add(vehicle);
        }
    }
}

//public class Vehicle
//{

//    [Required(ErrorMessage = "Make is required")]
//    public string Make { get; internal set; }
//    [MinLength(4)]
//    [MaxLength(4)]
//    [Required(ErrorMessage = "Year is required")]
//    public int Year { get; internal set; }
//    [Required(ErrorMessage = "Model is required")]
//    public string Model { get; internal set; }
//}