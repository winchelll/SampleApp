﻿using System;

namespace SampleApp
{
    internal class AppLogger
    {
        public AppLogger()
        {
        }

        internal void LogInfo(string v)
        {
           // throw new NotImplementedException();
        }
    }
}