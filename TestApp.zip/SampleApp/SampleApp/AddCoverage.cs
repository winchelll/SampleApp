﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleApp
{
    public class AddCoverage
    {
        public static void Add(Vehicle vehicle)
        {
            Console.WriteLine("Welcome");

            Console.WriteLine("What is Vehicle Make?");
            vehicle.Make = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(vehicle.Make))
            {
                Console.WriteLine("Make required");
                vehicle.Make = Console.ReadLine();
                //return ;
            }

            Console.WriteLine("What is Vehicle Model?");
            vehicle.Model = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(vehicle.Model))
            {
                Console.WriteLine("Model required");
                vehicle.Make = Console.ReadLine();
                //return ;
            }

            Console.WriteLine("What is Vehicle Year?");
            string yearInput = Console.ReadLine();
            //vehicle.Year = Console.ReadLine();
            if (int.TryParse(yearInput, out int vehicleYear))
            {
                vehicle.Year = vehicleYear;
                if ((vehicle.Year.ToString().Length != 4) && (vehicle.Year > 2000))
                { Console.WriteLine("Invalid vehicle year"); }
                vehicle.Year = Convert.ToInt32(Console.ReadLine());
            }
            else
            {
                Console.WriteLine("Invalid vehicle year");
                yearInput = Console.ReadLine();
                // return;
            }

            //if (vehicle.Year > 2000)
            //{
            //    Console.WriteLine("Invalid vehicle year");
            //    // appLoger.LogInfo("Invalid vehicle year");
            //    return;
            //}
            vehicle.Coverage.Add(new Coverage());
            Console.WriteLine("Successfully added coverage to vehicle");
        }
    }
}
