﻿using System.ComponentModel.DataAnnotations;

namespace SampleApp
{
    public class Vehicle
    {
        [Required(ErrorMessage = "Make is required")]
        public string Make { get; set; }
        [MinLength(4)]
        [MaxLength(4)]
        [Required(ErrorMessage = "Year is required")]
        public int Year { get;  set; }
        [Required(ErrorMessage = "Model is required")]
        public string Model { get;  set; }
    }
}