
using SampleApp;
using System;
using Xunit;

namespace TestProject2
{
    public class UnitTest1
    {


        [Fact]
        public void Fail()
        {
            // Arrange
            Vehicle vehicle = new Vehicle
            {
                Year = 2001,
                Make = "Ford",
                Model = "Mustang"
            };

            // Act
            AddCoverage.Add(vehicle);

            // Assert
            Assert.False(vehicle.Year.Equals(1999), "Invalid Vehicle Year");

        }

        [Fact]
        public void Success()
        {
            // Arrange
            Vehicle vehicle = new Vehicle
            {
                Year = 1999,
                Make = "Ford",
                Model = "Mustang"
            };

            // Act
            AddCoverage.Add(vehicle);

            // Assert
            Assert.True(vehicle.Year.Equals(1999), "Coverage Added");

        }


    }
}
